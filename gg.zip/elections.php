<?php
include 'config.php';

if (isset($_POST['close'])) {
    $stmt = $conn->prepare("UPDATE elections SET status='closed' WHERE id=?");
    $stmt->bind_param("i", $_POST['id']);
    $stmt->execute();
}
if (isset($_POST['reopen'])) {
    $stmt = $conn->prepare("UPDATE elections SET status='open' WHERE id=?");
    $stmt->bind_param("i", $_POST['id']);
    $stmt->execute();
}

$result = $conn->query("SELECT * FROM elections");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Elections</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
<div class="container">
    <h2>Manage Elections</h2>
    <table>
        <tr><th>Title</th><th>Status</th><th>Action</th></tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['title']) ?></td>
                <td><?= htmlspecialchars($row['status']) ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <?php if ($row['status'] === 'open'): ?>
                            <button type="submit" name="close">Close</button>
                        <?php else: ?>
                            <button type="submit" name="reopen">Reopen</button>
                        <?php endif; ?>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
    <a href="admin.php" class="back-btn">← Back to Admin Dashboard</a>
</div>
</body>
</html>
