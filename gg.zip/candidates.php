<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "voting_system";

$conn = new mysqli($host, $user, $password, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add Candidate
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_candidate'])) {
    $name = $_POST['name'];
    $position_id = $_POST['position_id'];

    $stmt = $conn->prepare("INSERT INTO candidates (name, position_id) VALUES (?, ?)");
    $stmt->bind_param("si", $name, $position_id);
    $stmt->execute();
    $stmt->close();
}

// Delete Candidate
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM candidates WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: candidates.php");
    exit;
}

// Fetch all positions with election titles
$positions = $conn->query("
    SELECT positions.id AS id, positions.title AS position_title, elections.title AS election_title
    FROM positions
    JOIN elections ON positions.election_id = elections.id
    ORDER BY elections.title, positions.title
");

// Fetch all candidates with position and election info
$candidates = $conn->query("
    SELECT candidates.id AS id,
           candidates.name AS candidate_name, 
           positions.title AS position_title, 
           elections.title AS election_title
    FROM candidates
    JOIN positions ON candidates.position_id = positions.id
    JOIN elections ON positions.election_id = elections.id
    ORDER BY elections.title, positions.title
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Candidates</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
<div class="container">
    <a href="admin.php" class="back-btn">← Back to Admin Dashboard</a>
    <h2>Manage Candidates</h2>

    <form method="POST">
        <label for="name">Candidate Name:</label>
        <input type="text" name="name" required>

        <label for="position_id">Select Position (with Election):</label>
        <select name="position_id" required>
            <option value="">Select Position</option>
            <?php while ($row = $positions->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>">
                    <?= htmlspecialchars($row['election_title']) ?> – <?= htmlspecialchars($row['position_title']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <button type="submit" name="add_candidate">Add Candidate</button>
    </form>

<h3>Existing Candidates</h3>
<table>
    <thead>
        <tr>
            <th>Candidate Name</th>
            <th>Election</th>
            <th>Position</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($candidates->num_rows > 0): ?>
            <?php while ($row = $candidates->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['candidate_name']) ?></td>
                    <td><?= htmlspecialchars($row['election_title']) ?></td>
                    <td><?= htmlspecialchars($row['position_title']) ?></td>
                    <td>
                        <form method="GET" onsubmit="return confirm('Are you sure you want to delete this candidate?');" style="display:inline;">
                            <input type="hidden" name="delete" value="<?= $row['id'] ?>">
                            <button type="submit" class="btn small danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="4">No candidates found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

</div>
</body>
</html>
