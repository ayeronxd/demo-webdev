<?php
session_start();
include 'config.php';

$res = $conn->query("SELECT id, title FROM elections WHERE status='open'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Select Election</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Select Election to Vote In</h2>
    <form method="get" action="vote.php">
        <select name="election_id" required>
            <?php while ($row = $res->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['title']) ?></option>
            <?php endwhile; ?>
        </select>
        <button type="submit">Continue</button>
    </form>
</div>
</body>
</html>
